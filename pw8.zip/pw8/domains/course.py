from domains.entity import Entity


class Course(Entity):
    def __init__(self):
        super().__init__()
        self.__marks = {}

    def input(self):
        self._id = input("  Course ID: ").strip()
        self._name = input("  Course name: ").strip()

    def list(self):
        print(f"  {self._id:<10} {self._name}")

    def set_mark(self, student_id, mark):
        if mark < 0 or mark > 20:
            raise ValueError("Mark must be between 0 and 20")
        self.__marks[student_id] = mark

    def get_mark(self, student_id):
        return self.__marks.get(student_id)
