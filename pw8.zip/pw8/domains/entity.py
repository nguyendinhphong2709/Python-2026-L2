class Entity:
    def __init__(self):
        self._id = ""
        self._name = ""

    def get_id(self):
        return self._id

    def get_name(self):
        return self._name

    def input(self):
        raise NotImplementedError

    def list(self):
        raise NotImplementedError
