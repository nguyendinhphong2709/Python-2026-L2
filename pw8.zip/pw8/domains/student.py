from domains.entity import Entity


class Student(Entity):
    def __init__(self):
        super().__init__()
        self.__dob = ""

    def get_dob(self):
        return self.__dob

    def input(self):
        self._id = input("  Student ID: ").strip()
        self._name = input("  Student name: ").strip()
        self.__dob = input("  Date of birth (dd/mm/yyyy): ").strip()

    def list(self):
        print(f"  {self._id:<10} {self._name:<25} {self.__dob}")
