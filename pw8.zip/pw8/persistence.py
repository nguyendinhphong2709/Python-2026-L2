import copy
import gzip
import os
import pickle
import threading

DATA_FILE = "students.dat"


class Persistence:
    def __init__(self, path=DATA_FILE):
        self.__path = path
        self.__lock = threading.Lock()
        self.__thread = None

    def load(self):
        if not os.path.exists(self.__path):
            return None
        with gzip.open(self.__path, "rb") as f:
            return pickle.load(f)

    def __write(self, data):
        with self.__lock:
            tmp = self.__path + ".tmp"
            with gzip.open(tmp, "wb") as f:
                pickle.dump(data, f)
            os.replace(tmp, self.__path)

    def save_async(self, data):
        snapshot = copy.deepcopy(data)
        self.__thread = threading.Thread(target=self.__write, args=(snapshot,), daemon=False)
        self.__thread.start()

    def wait(self):
        if self.__thread is not None:
            self.__thread.join()
